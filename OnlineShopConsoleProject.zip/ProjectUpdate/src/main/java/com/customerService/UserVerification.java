package com.customerService;
import java.util.InputMismatchException;
import java.util.Scanner;


import com.Exception.ShoppingException;
import com.dao.CustomerManagement;

public class UserVerification {
	public Customer verify() {
		int choice;
		Scanner sc = new Scanner(System.in);
		while(true) {
	
			try {
				System.out.println("\nPlease choose options:\n1.LogIn\n2.SignUp");
				choice= sc.nextInt();
				if(choice ==1 ) {
					//sc.close();
					return logInFn();
				}
				else if(choice==2){
					//sc.close();
					return signUpFn();
				}
				else {
					System.out.println("Invalid choice");
				}
			} catch (InputMismatchException e) {
				System.out.println("incorrect Input!");
				sc.nextLine();
			}
			
		}
	}

	private Customer signUpFn()  {
		Scanner sc = new Scanner(System.in);
		CustomerManagement cstmrDao= new CustomerManagement();
		System.out.println("Enter your details for signup process");

		
		System.out.print("Enter your Name:");
		String name= sc.next();
		String email;
		String address;
		String mob;
		String pass;
		
		//for taking email id------------------
		while(true) {
			try {
				System.out.print("Enter your Email:");
				email = sc.next().trim();
				String regexPattern = "^(?=(.{1,64}@))[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";

				if (email.matches(regexPattern)) {
				    System.out.println("Valid email address!");
				    Customer cObj = cstmrDao.getCustomerByEmail(email);
					if(cObj!=null) {
						throw new ShoppingException("Email Id already exists");
					}
					else {
						break;
					}
				} else {
					throw new ShoppingException("Invalid email");
				}
			} catch (ShoppingException e) {
				System.out.println(e.getMessage());
			} 
			
		}
		
//for taking mobile------------------
		while(true) {
			try {
				System.out.print("Enter your Mobile No:");
				mob = sc.next().trim();
				String regexPattern = "^\\d{10}$";

				if (mob.matches(regexPattern)) {
				    System.out.println("Valid Mobile number!");
				    break;
				} else {
					throw new ShoppingException("Invalid Mobile Number!");
				}
			} catch (ShoppingException e) {
				System.out.println(e.getMessage());
			} 
		}
		
//for taking address------------------
		sc.nextLine();
		while(true) {
			try {
				System.out.print("Enter your address:");
				address = sc.nextLine();
				String regexPattern = ".{4,}";

				if (address.matches(regexPattern)) {
				    System.out.println("Valid address!");
				    break;
				} else {
					throw new ShoppingException("Invalid address! its too short");
				}
			} catch (ShoppingException e) {
				System.out.println(e.getMessage());
			} 
		}
	
//for taking password------------------
		while(true) {
			try {
				System.out.print("Create your Password:");
				pass = sc.next();
				String regexPattern = ".{4,}";

				if (pass.matches(regexPattern)) {
				    System.out.println("Password entered!");
				    break;
				} else {
					throw new ShoppingException("Invalid Password! try stronger password");
				}
			} catch (ShoppingException e) {
				System.out.println(e.getMessage());
			} 
		}
		
		Customer custmr = new Customer( name, email,  address,  mob,  pass);
		int id = cstmrDao.addCustomer(custmr);
		if(id!=-1) {
			custmr.setId(id);
			System.out.println("Registration Successfull, Your customer id is "+id);
		}
		else {
			System.out.println("Registration failed!!");
		}
		return custmr;
	}

	
	
	
	private Customer logInFn() {
		String email;
		String pass;
		Scanner sc = new Scanner(System.in);
		CustomerManagement cstmrDao= new CustomerManagement();
		Customer c=null;
		while(true) {
			try {
				System.out.print("Enter your Email:");
				//sc.nextLine();
				email = sc.nextLine().trim();
				//String regexPattern = "^(?=(.{1,64}@))[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
				c = cstmrDao.getCustomerByEmail(email);
				if (c==null) {
					throw new ShoppingException("Email Id does not exists");
				} else {
					break;
				}
			} catch (ShoppingException e) {
				System.out.println(e.getMessage());
			} 
			
		}
		
		//System.out.println(c.getPass());
	//for taking password------------------
		for(int i=5;i>0;i--) {
			try {
				System.out.print("\nEnter your Password:");
				pass = sc.next();
				

				if (pass.equals(c.getPass())) {
				    System.out.println("Correct Password entered!");
				    return c;
				    //break;
				} else {
					throw new ShoppingException(" Incorrect Password ");
				}
			} catch (ShoppingException e) {
				System.out.println(e.getMessage());
				System.out.println("Attempts Remaining: "+ (i-1));
			} 
		}
		System.out.println("Max attempts limit reached, Try again after some time!!");
		return null;
	}
}
