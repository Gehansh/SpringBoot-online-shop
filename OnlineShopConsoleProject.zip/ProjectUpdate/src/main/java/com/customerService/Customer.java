package com.customerService;

public class Customer {
	private int id;
	private String name;
	private String email;
	private String address;
	private String mob;
	private String pass;
	
	public Customer() {
		super();
	}
	public Customer(int id, String name, String email, String address, String mob, String pass) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.address = address;
		this.mob = mob;
		this.pass = pass;
	}
	public Customer(String name2, String email2, String address2, String mob2, String pass2) {
		// TODO Auto-generated constructor stub
		super();
		this.name = name2;
		this.email = email2;
		this.address = address2;
		this.mob = mob2;
		this.pass = pass2;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", email=" + email + ", address=" + address + ", mob=" + mob
				+ ", pass=" + pass + "]";
	}
}
