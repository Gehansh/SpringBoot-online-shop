package com.Exception;

public class ShoppingException extends Exception {

    public ShoppingException(String message) {
        super(message);
    }

    public ShoppingException(String message, Throwable cause) {
        super(message, cause);
    }
}
