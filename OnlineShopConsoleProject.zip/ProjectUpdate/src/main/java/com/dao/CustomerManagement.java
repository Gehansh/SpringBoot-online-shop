package com.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;


import com.customerService.Customer;
import com.productService.Product;

public class CustomerManagement {

	public Customer getCustomerByEmail(String email) {
		try {
			Connection conn = DB.getConnection();
			String sql = "select * from customers where email ='"+email+"'";
			PreparedStatement statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			
			Customer c= new Customer();
			while(rs.next()) {
				c.setId(rs.getInt("customer_id"));
				c.setName(rs.getString("customer_name"));
				c.setEmail(rs.getString("email"));
				c.setAddress(rs.getString("address"));
				c.setMob(rs.getString("mob"));
				c.setPass(rs.getString("pass"));
				//System.out.println(c);
				return c;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	
	
	public int addCustomer(Customer c) {
		try {
			Connection conn = DB.getConnection();
			String sql = "insert into customers (customer_name,email,address,pass,mob)  values(?,?,?,?,?)";
			PreparedStatement statement = conn.prepareStatement(sql);
			
			statement.setString(1, c.getName());
			statement.setString(2, c.getEmail());
			statement.setString(3, c.getAddress());
			statement.setString(4, c.getPass());
			statement.setString(5, c.getMob());
			
			statement.executeUpdate();
			statement.close();
			//conn.close();
			System.out.println("Customer Details Added Successfully");	
			//for fetching customer id;
			String sql2 = "select customer_id from customers where email ='"+c.getEmail()+"'";
			PreparedStatement statement2 = conn.prepareStatement(sql2);
			ResultSet rs = statement2.executeQuery();
			int id=-1;
			while(rs.next()) {
        		id= rs.getInt("customer_id");
        	}
			return id;
			
		} catch (SQLException e) {
			System.out.println("Error in registering customer, try again!");
			e.printStackTrace();
			return -1;
		}
		
	}



	public void addOrder(int cid, HashMap<Product, Integer> cartmp) {
		
		try {
			Connection conn = DB.getConnection();
			
			for(Product x: cartmp.keySet()) {
				String sql = "INSERT INTO orders ( customer_id, product_id, order_date, quantity) VALUES (?, ?,CURDATE(), ?)";
				PreparedStatement statement = conn.prepareStatement(sql);
				statement.setInt(1, cid);
				statement.setInt(2, x.getId());
				statement.setInt(3, cartmp.get(x));
				statement.executeUpdate();
				statement.close();
			}
			
			
			conn.close();
			System.out.println("Orders Added Successfully");
		} catch (SQLException e) {
			System.out.println("Error in adding orders!");
			e.printStackTrace();
		}
		
	}



	public void fetchHistory(int cid) {
		try {
			Connection conn = DB.getConnection();
			String sql = "select * from orders o join products p on o.product_id = p.product_id where o.customer_id ="+cid;
			PreparedStatement statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			
			System.out.println("Order History~");
			System.out.println("---------------------------------------------------------------------------------");
			while(rs.next()) {
				System.out.println("=> Order Id:"+rs.getInt("order_id")+", Product Id:"+rs.getInt("product_id")+",  Name: "+rs.getString("product_name")+",  Price:"+rs.getInt("product_price")+",  Quantity:"+rs.getInt("quantity")+",  Order Date:"+rs.getDate("order_date"));
		
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
