package com.productService;

import java.util.*;


import com.dao.CustomerManagement;

public class ShoppingCartUtility {
	
	private HashMap<Product,Integer> cartmp = new HashMap<Product,Integer>();
	private List<Product> cartItems = new ArrayList<Product>();
	
	
    public void addToCart(Product product) {
//        cartItems.add(product);
//        System.out.println(product.getName()+" $"+product.getPrice() + " added to cart.");
//        
        
        //for map
    	System.out.println(product.toString());
        for(Product x: cartmp.keySet()) {
        	if(x.getId()==product.getId()) {
        		System.out.println("*");
        		cartmp.put(x, cartmp.get(x)+1);
        		System.out.println(x.getName()+" ₹"+x.getPrice() + " added to cart.");
        		return;
        	}
        }
        cartmp.put(product, 1);
		System.out.println(product.getName()+" ₹"+product.getPrice() + " added to cart.");
		return;
    }

    
   public void removeFromCart(Product product) {
    	 //System.out.println(cartItems+"  "+product);
//    	 for(Product p:cartItems) {
//    		 if(p.getId()==product.getId()) {
//    			 cartItems.remove(p);
//    			 System.out.println(product.getName() + " removed from cart.");
//    			 return ;
//    		 }
//    	 }
//    	 System.out.println(product.getName() + " is not in the cart.");
//    	 
    	 //for map
    	 for(Product x:cartmp.keySet()) {
    		 if(x.getId()==product.getId()) {
    			 if(cartmp.get(x)>1) {
    				 cartmp.put(x, cartmp.get(x)-1);
    				 System.out.println(product.getName() + " removed from cart.");
        			 return ;
    			 }
    			 else if(cartmp.get(x)==1) {
    				 cartmp.remove(x);
    				 System.out.println(product.getName() + " removed from cart.");
        			 return ;
    			 }
    		 }
    	 }
    	 System.out.println(product.getName() + " is not in the cart.");
    	 
    }

    public void viewCart() {
//        System.out.println("Items in cart:"+cartItems.size());
//        
//        for (Product item : cartItems) {
//            System.out.println(item.getName() + " - $" + item.getPrice());
//        }
        
        //for map
//    	System.out.println("Items in cart: "+cartmp.size());
//        for(Product x: cartmp.keySet()) {
//        	System.out.println(x.toString()+ " Quantity:"+ cartmp.get(x));
//        }
    	double totalBill = 0;
        System.out.println("\nCART - (Total Items: "+cartmp.size()+")");
        System.out.println("-----------------------------");
        for (Product item : cartmp.keySet()) {
            totalBill += item.getPrice()* cartmp.get(item);
            System.out.println(item.getName() + " - ₹" + item.getPrice() +" * "+ cartmp.get(item));
        }
        System.out.println("-----------------------------");
        System.out.println("Cart Total : ₹" + totalBill);
        return;
    }

//    public double calculateBill() {
//        
//    }

	public void buyAllitems(int id) {
		CustomerManagement cm =new CustomerManagement();
		if(cartmp.size()>0) {
			cm.addOrder(id,cartmp);
			
			double totalBill = 0;
	        System.out.println("\nBILL - (Total Items: "+cartmp.size()+")");
	        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	        for (Product item : cartmp.keySet()) {
	            totalBill += item.getPrice()* cartmp.get(item);
	            System.out.println(item.getName() + " - ₹" + item.getPrice() +" * "+ cartmp.get(item));
	        }
	        System.out.println("==================================");
	        System.out.println("Bill Total : ₹" + totalBill);
	        System.out.println("==================================");
	        System.out.println("Your orders will be delivered to your given address in 3 days.");
	        cartmp.clear();
	        return;
		}
		System.out.println("No items in cart to buy!!");
        return ;
	}


	public void showHistory(int cid) {
		CustomerManagement cm =new CustomerManagement();
		cm.fetchHistory(cid);
		
	}


}