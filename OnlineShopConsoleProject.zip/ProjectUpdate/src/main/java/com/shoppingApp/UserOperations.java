package com.shoppingApp;

import com.customerService.Customer;
import com.customerService.UserVerification;
import com.dao.*;
import com.productService.*;

import java.sql.*;
import java.util.*;

public class UserOperations {
	public void adminFn() throws SQLException {
		
    	System.out.println("\nYou Logged In as Admin. Please choose options:");
            Scanner sc = new Scanner(System.in);
            while (true) {
                System.out.println("\n------------\nOptions-\n1. Add Product");
                System.out.println("2. View Products");
                System.out.println("3. Update Product");
                System.out.println("4. Delete Product");
                System.out.println("5. Total Sales/Revenue");
                System.out.println("6. Exit");
                System.out.print("Enter your choice: ");
                int choice;
				try {
					choice = sc.nextInt();
				} catch (InputMismatchException e) {
					sc.nextLine();
					System.out.println("incorrect Input!");
					continue;
				}
                System.out.print("\n");
                //scanner.nextLine(); // Consume newline
                ProductManagement productDoaObj = new ProductManagement();
                IOHelper ioObj = new IOHelper();
                
                switch (choice) {
                
                    case 1:
                    	System.out.println("Add product option Selected");
                    	Product product = ioObj.getProductDetails(sc);
                    	if(product != null)productDoaObj.addProduct(product);
                        break;
                        
                    case 2:
                    	System.out.println("View products option Selected");
                    	List<Product> productList = new ArrayList<Product>();
                    	productList=productDoaObj.getAllProductsList();
                    	ioObj.displayProducts(productList);
                        break;
                        
                    case 3:
                    	System.out.println("Update product option Selected");
                    	Product product1 = ioObj.getProductDetailsForUpdation(sc);
                    	if(product1 != null) productDoaObj.updateProduct(product1);
                        break;
                    case 4:
                    	System.out.println("Delete product option Selected");
                    	int id = ioObj.getProductIDForDeletion(sc);
                    	if(id != -1)productDoaObj.deleteProduct(id);
                        break;
                    case 5:
                    	System.out.println("Show Sales option Selected");
                    
                    	productDoaObj.showSales();
                        break;
                    case 6:
                        System.out.println("\n===== Bye, Have a Good Day!! =====\n");
                        return;
                    default:
                        System.out.println("Invalid choice. Try again.");
                        //adminFn();
                }
            }   
	}
    
    
    //method for customer Operations 
    public void customerFn() throws SQLException {
			
    		UserVerification cstmrVrfyObj = new UserVerification();
    		Customer c= cstmrVrfyObj.verify();
    		
    		if(c==null) {
    			System.out.println("Failed to enter!");
    			return;
    		}
    		else {
    			
    			System.out.println("\nYou Logged In as Customer.(Id-"+c.getId()+" "+c.getName()+")");
    			System.out.println("Please choose the operation:");
    		}
    		
            Scanner sc = new Scanner(System.in);
            ProductManagement productDoaObj = new ProductManagement();
            ShoppingCartUtility cartObj = new ShoppingCartUtility();
            IOHelper ioObj = new IOHelper();
            while (true) {
            	System.out.println("\n~~~~~~~~\nOptions-\n1. View all available products");
                System.out.println("2. Add product to cart");
                System.out.println("3. Remove item from cart");
                System.out.println("4. View Cart");
                System.out.println("5. Search the product details");
                System.out.println("6. Buy all items in cart");
                System.out.println("7. Show orders History");
                System.out.println("8. Exit");
                System.out.print("Enter your choice: ");
                int choice;
				try {
					choice = sc.nextInt();
				} catch (InputMismatchException e) {
					sc.nextLine();
					System.out.println("incorrect Input!");
					continue;
				}
                System.out.print("\n");
                //scanner.nextLine(); // Consume newline
                
                switch (choice) {
                
                    case 1:
                    	System.out.println("View all available products option Selected");
                    	List<Product> productList = new ArrayList<Product>();
                    	productList=productDoaObj.getAllProductsList();
                    	ioObj.displayProducts(productList);
                        break;
                        
                    case 2:
                    	System.out.println("Add item to cart option Selected");
                    	Product product = ioObj.getProductDetailsForAddingToCart(sc);
                    	if(product != null) cartObj.addToCart(product);
                        break;
                        
                    case 3:
                    	System.out.println("Remove item from cart option Selected");
                    	Product product1 = ioObj.getProductDetailsForDeletion(sc);
                    	if(product1 != null) cartObj.removeFromCart(product1);
                        break;
                    case 4:
                    	System.out.println("View cart option Selected");
                    	cartObj.viewCart();
                        break;
                        
                    case 5:
                    	System.out.println("Enter product name to be searched:");
                    	sc.nextLine();
                    	String name = sc.nextLine();
                    	int rs = productDoaObj.searchProduct(name);
                    	
                    	if(rs==0) {
                    		System.out.println("Product not found! Please type correct product name");
                    	}
                    	break;
                    case 6:
                    	System.out.println("Buy all items in cart option Selected");
                    	cartObj.buyAllitems(c.getId());
                    	break;
                    case 7:
                    	System.out.println("show history option Selected");
                    	cartObj.showHistory(c.getId());
                    	break;
                    case 8:
                        System.out.println("\n===== Thanks for Shopping, Have a Good Day!! =====\n");
                        return;
                    default:
                        System.out.println("Invalid choice. Try again.");
                        customerFn();
                }
            }   
	}
    
}
