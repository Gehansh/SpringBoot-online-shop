package com.shoppingApp;

import java.util.*;


public class App {
 
//    @SuppressWarnings("resource")
	public static void main(String args[]) throws Exception
    {
    	UserOperations appObj= new UserOperations();
    	Scanner sc = new Scanner(System.in);
    	System.out.println("======WELCOME TO THE ONLINE SHOP======");
    	System.out.println("--------------------------------------");
    	System.out.println("Select your type:\n1.Admin\n2.Customer");
    	
    	boolean condition =true;
    	while(condition) {
				try {
					int userType =  sc.nextInt();
					switch (userType) {
					case 1:
						appObj.adminFn();
						condition= false;
						break;
					case 2:
						appObj.customerFn();
						condition= false;
						break;
					default:
						System.out.println("Select correct option..");
					
					}
				} catch (InputMismatchException e) {
					sc.nextLine();
					System.out.println("incorrect input!");
					System.out.println("Select your type:\n1.Admin\n2.Customer");
				}
    	}
    	sc.close();
    	//System.out.println("Program Finished!!");
    }
    
  
} 
